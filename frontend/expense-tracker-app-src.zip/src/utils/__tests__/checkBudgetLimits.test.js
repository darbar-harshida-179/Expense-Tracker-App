// frontend/src//utils/__tests__/checkBudgetLimits.test.js

import { describe, test, expect, vi } from "vitest";
import checkBudgetLimit from "../checkBudgetLimits";
import { toast } from "react-toastify";

vi.mock("react-toastify", () => ({
    toast: {
        error: vi.fn(),
        warning: vi.fn()
    }
}))

describe("checkBudgetLimit", () => {

    test("returns true when budget is not exceeded", () => {

        const expenses = [
            {
                category: "food",
                amount: 1000
            }
        ];

        const values = {
            category: "food",   
            amount: 500
        };

        const result = checkBudgetLimit(
            expenses,
            values
        );

        expect(result).toBe(true);
    });

    test("returns false when budget limit is exceeded", () => {

        const expenses = [
            {
                category: "food",
                amount: 19500
            }
        ];

        const values = {
            category: "food",
            amount: 1000
        };

        const result = checkBudgetLimit(
            expenses,
            values
        );

        expect(result).toBe(false);
    });

    test("shows warning toast when spending reaches 80 percent of budget", () => {

        const expenses = [
            {
                category: "food",
                amount: 15000
            }
        ];

        const values = {
            category: "food",
            amount: 1000
        };

        checkBudgetLimit(
            expenses,
            values
        );

        expect(toast.warning).toHaveBeenCalled();
    });

    test("shows error toast when budget limit is exceeded", () => {

        const expenses = [
            {
                category: "food",
                amount: 19500
            }
        ];

        const values = {
            category: "food",
            amount: 1000
        };

        checkBudgetLimit(
            expenses,
            values
        );

        expect(toast.error).toHaveBeenCalled();
    });

    test("ignores current expense when editing", () => {

        const expenses = [
            {
                _id: "1",
                category: "food",
                amount: 19500
            }
        ];

        const values = {
            category: "food",
            amount: 1000
        };

        const result = checkBudgetLimit(
            expenses,
            values,
            "1"
        );

        expect(result).toBe(true);
    });
});
