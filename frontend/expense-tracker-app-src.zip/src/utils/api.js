// frontend/src/utils/api.js

import axios from 'axios';

const API = axios.create({
    baseURL: 'http://localhost:5000/api'
})

API.interceptors.request.use((req) => {
    const appData = JSON.parse(localStorage.getItem("Expense-Tracker-App"));
    const token = appData?.token;
    if (token) {
        req.headers.Authorization = `Bearer ${token}`;
    }
    return req;
})
export default API;

