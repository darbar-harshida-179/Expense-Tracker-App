// frontend/src/utils/formatCurrency.js

export const formatCurrency = (amount) => {
    
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0
    }).format(amount);
}