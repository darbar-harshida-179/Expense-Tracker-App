// frontend/src/components/__tests__/UsersExpensesCards.test.jsx

import { render, screen } from "@testing-library/react";
import { describe, test, expect, vi } from "vitest";
import UsersExpensesCards from "../UsersExpensesCards";
import userEvent from "@testing-library/user-event";

// Mock API
vi.mock("../../services/expenseServices", () => ({
    getExpenses: vi.fn(() =>
        Promise.resolve({
            data: []
        })
    ),
    addExpense: vi.fn(),
    updateExpense: vi.fn(),
    deleteExpense: vi.fn()
}));

// Mock hook
vi.mock("../../hooks/useSelectedMonth", () => ({
    default: () => ({
        selectedDate: new Date("2026-06-01"),
        setSelectedDate: vi.fn()
    })
}));

// Mock child components
vi.mock("../Navbar", () => ({
    default: ({ setOpenModal }) => (
        <div>
            Navbar
            <button onClick={() => setOpenModal(true)}>
                Open Modal
            </button>
        </div>
    )
}));

vi.mock("../AddExpenseModal", () => ({
    default: () => <div>AddExpenseModal</div>
}));

vi.mock("../EditExpenseModal", () => ({
    default: () => <div>EditExpenseModal</div>
}));

vi.mock("../DeleteExpenseModal", () => ({
    default: () => <div>DeleteExpenseModal</div>
}));

vi.mock("../Loading", () => ({
    default: () => <div>Loading...</div>
}));

describe("UsersExpensesCards", () => {

    test("renders navbar", async () => {

        render(
            <UsersExpensesCards />
        );

        expect(
            await screen.findByText("Navbar")
        ).toBeInTheDocument();
    });

    test("shows no expenses message", async () => {

        render(
            <UsersExpensesCards />
        );

        expect(
            await screen.findByText(
                "No Expenses Found!"
            )
        ).toBeInTheDocument();
    });

    test("shows add first expense button", async () => {

        render(
            <UsersExpensesCards />
        );

        expect(
            await screen.findByText(
                "Add Your First Expense"
            )
        ).toBeInTheDocument();
    });

    test("opens add expense modal", async () => {

        render(
            <UsersExpensesCards />
        );

        const button = await screen.findByText(
            "Open Modal"
        );

        await userEvent.click(button);

        expect(
            screen.getByText("AddExpenseModal")
        ).toBeInTheDocument();
    });

});